package com.WatchMovie.AndroidSport.model.entity;

/**
 * 在Post请求中的将key-value封装的类
 * Created by WatchMovie on 17/8/12
 */
public class PostRequestBody {
    public String name;
    public String value;
}

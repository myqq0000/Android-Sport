package com.WatchMovie.AndroidSport.model.entity;

/**
 * 所有返回的数据的基类
 * Created by WatchMovie on 17/8/12
 */
public class BaseResult {
    private int result;

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }
}
